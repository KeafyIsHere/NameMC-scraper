﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
namespace MinecraftUsernameScraper
{
    class Program
    {
        private static WebClient wc = new WebClient();
        private static readonly List<string> usernames = new List<string>();
        static void Main(string[] args)
        {


            Console.WriteLine("What is the highest amount of characters should the username have?");
            string input = Console.ReadLine();
            if (!int.TryParse(input, out int numofchar)) 
            {
                Console.WriteLine(input + " is not a number!");
                Thread.Sleep(-1);
            }
            string url = "https://namemc.com/minecraft-names";
            for (int i = 0; i < 20; i++)
            {
                wc.Headers.Add(HttpRequestHeader.UserAgent, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287");
                Console.WriteLine(url);
                string data = wc.DownloadString(url);
                var splits = data.Split(new string[] { "/name/" }, StringSplitOptions.None);
                usernames.AddRange(from string split2 in splits
                                   let username = split2.Split('"')[0].Trim()
                                   where username.Length <= 11
                                   select username);

                foreach (var a in data.Split(new string[] { "/minecraft-names?time=" }, StringSplitOptions.None).Where(a => a.Contains("next")))
                {
                    url = "https://namemc.com/minecraft-names?time=" + a.Split('"')[0];
                }
                wc.Dispose();
            }
            File.AppendAllLines("usernames.txt", usernames.Distinct());
        }
    }
}
